class Horserace:
    jockeys = list()
    def __init__(self, race_type):
        self.race_type = race_type


