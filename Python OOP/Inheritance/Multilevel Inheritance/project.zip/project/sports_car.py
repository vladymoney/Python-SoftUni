from project.car import Car


class Sportscar(Car):
    def race(self):
        return "racing..."